from django.apps import AppConfig


class TraiapConfig(AppConfig):
    name = 'traiap'
